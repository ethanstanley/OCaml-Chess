open Array
open Yojson.Basic.Util

exception Malformed

exception DoesNotExist

exception InvalidMove

exception MoveUnfeasible

type p_color =
  | White
  | Black
  | None

type piece =
  | Pawn of p_color
  | King of p_color
  | Queen of p_color
  | Knight of p_color
  | Bishop of p_color
  | Rook of p_color
  | None

type position = char * int

type space = {
  position_id : position;
  is_open : bool;
  piece_id : piece;
  color : p_color;
}

type board = space list list

let to_position str : position =
  let letter = String.get str 0 in
  let num = int_of_string (String.sub str 3 1) in
  (letter, num)

let to_color s =
  match s with
  | "Black" -> Black
  | "White" -> White
  | _ -> None

let color_to_str c =
  match c with
  | Black -> "Black"
  | White -> "White"
  | None -> ""

let to_piece = function
  | "Rook White" -> Rook White
  | "Rook Black" -> Rook Black
  | "Bishop White" -> Bishop White
  | "Bishop Black" -> Bishop Black
  | "Knight White" -> Knight White
  | "Knight Black" -> Knight Black
  | "Queen White" -> Queen White
  | "Queen Black" -> Queen Black
  | "King White" -> King White
  | "King Black" -> King Black
  | "Pawn White" -> Pawn White
  | "Pawn Black" -> Pawn Black
  | _ -> None

let to_space
    (id : string)
    (avail : bool)
    (piece : string)
    (color : string) =
  {
    position_id = to_position id;
    is_open = avail;
    piece_id = to_piece piece;
    color = to_color color;
  }

let defaultempty = to_space "Z, 0" false "none" "none"

let spaces_of_json j =
  {
    position_id = j |> member "position_id" |> to_string |> to_position;
    is_open = j |> member "is_open" |> to_bool;
    piece_id = j |> member "piece_id" |> to_string |> to_piece;
    color = j |> member "color" |> to_string |> to_color;
  }

let rows_of_json j : space list = j |> List.map spaces_of_json

let from_json json =
  json |> member "rows" |> to_list |> List.map to_list
  |> List.map rows_of_json

let start_board : board =
  from_json (Yojson.Basic.from_file "./boards/start_board.json")

let print_piece = function
  | Pawn White -> "♟︎"
  | Pawn Black -> "♙"
  | Pawn None -> " "
  | King White -> "♚"
  | King Black -> "♔"
  | King None -> " "
  | Queen White -> "♛"
  | Queen Black -> "♕"
  | Queen None -> " "
  | Knight White -> "♞"
  | Knight Black -> "♘"
  | Knight None -> " "
  | Bishop White -> "♝"
  | Bishop Black -> "♗"
  | Bishop None -> " "
  | Rook White -> "♜"
  | Rook Black -> "♖"
  | Rook None -> " "
  | None -> " "

let parse_str str =
  if String.length str != 2 then raise Malformed
  else
    (Char.uppercase_ascii str.[0], int_of_string (String.make 1 str.[1]))

let rec find_space (square : position) (board : board) =
  match board with
  | [] -> raise DoesNotExist
  | h :: t -> (
      match List.find_opt (fun x -> x.position_id = square) h with
      | None -> find_space square t
      | Some sp -> sp)

let valid_space (space : position) =
  if
    snd space < 1 || snd space > 8 || fst space < 'A' || fst space > 'H'
  then false
  else true

let is_valid_move_king piece board start_space end_space =
  if
    Int.abs (Char.code (fst end_space) - Char.code (fst start_space))
    = 1
    && Int.abs (snd end_space - snd start_space) = 1
    || Int.abs (Char.code (fst end_space) - Char.code (fst start_space))
       = 0
       && Int.abs (snd end_space - snd start_space) = 1
    || Int.abs (Char.code (fst end_space) - Char.code (fst start_space))
       = 1
       && Int.abs (snd end_space - snd start_space) = 0
  then true
  else false

let is_valid_move_knight
    piece
    board
    (start_space : position)
    (end_space : position) =
  if
    Char.code (fst end_space) = Char.code (fst start_space) + 2
    && snd end_space = snd start_space + 1
    || Char.code (fst end_space) = Char.code (fst start_space) + 1
       && snd end_space = snd start_space + 2
    || Char.code (fst end_space) = Char.code (fst start_space) - 1
       && snd end_space = snd start_space + 2
    || Char.code (fst end_space) = Char.code (fst start_space) - 2
       && snd end_space = snd start_space + 1
    || Char.code (fst end_space) = Char.code (fst start_space) - 2
       && snd end_space = snd start_space - 1
    || Char.code (fst end_space) = Char.code (fst start_space) - 1
       && snd end_space = snd start_space - 2
    || Char.code (fst end_space) = Char.code (fst start_space) + 1
       && snd end_space = snd start_space - 2
    || Char.code (fst end_space) = Char.code (fst start_space) + 2
       && snd end_space = snd start_space - 1
  then true
  else false

let rec check_right_bishop board position1 position2 =
  if position1 = position2 then true
  else if (find_space position1 board).is_open then
    if snd position1 < snd position2 then
      check_right_bishop board
        (Char.chr (Char.code (fst position1) + 1), snd position1 + 1)
        position2
    else
      check_right_bishop board
        (Char.chr (Char.code (fst position1) + 1), snd position1 - 1)
        position2
  else false

let rec check_left_bishop board position1 position2 =
  if position1 = position2 then true
  else if (find_space position1 board).is_open then
    if snd position1 < snd position2 then
      check_left_bishop board
        (Char.chr (Char.code (fst position1) - 1), snd position1 + 1)
        position2
    else
      check_left_bishop board
        (Char.chr (Char.code (fst position1) - 1), snd position1 - 1)
        position2
  else false

let is_valid_move_bishop
    piece
    board
    (start_space : position)
    (end_space : position) =
  if
    Int.abs (Char.code (fst end_space) - Char.code (fst start_space))
    = Int.abs (snd end_space - snd start_space)
  then
    if Char.code (fst start_space) < Char.code (fst end_space) then
      if snd start_space < snd end_space then
        check_right_bishop board
          ( Char.chr (Char.code (fst start_space) + 1),
            snd start_space + 1 )
          end_space
      else
        check_right_bishop board
          ( Char.chr (Char.code (fst start_space) + 1),
            snd start_space - 1 )
          end_space
    else if snd start_space < snd end_space then
      check_left_bishop board
        (Char.chr (Char.code (fst start_space) - 1), snd start_space + 1)
        end_space
    else
      check_left_bishop board
        (Char.chr (Char.code (fst start_space) - 1), snd start_space - 1)
        end_space
  else false

let pawn_capture (color : string) board start_space end_space =
  if color = "white" then
    let e_space = find_space end_space board in
    (* print_endline (String.make 1 (fst end_space)); print_endline (snd
       end_space); print_endline (String.make 1 (fst start_space)); *)
    abs (int_of_char (fst end_space) - int_of_char (fst start_space))
    = 1
    && snd end_space = snd start_space + 1
    && e_space.is_open = false
    && e_space.color = to_color "Black"
  else if color = "black" then
    let e_space = find_space end_space board in
    abs (int_of_char (fst end_space) - int_of_char (fst start_space))
    = 1
    && snd end_space = snd start_space - 1
    && e_space.is_open = false
    && e_space.color = to_color "White"
  else false

let is_valid_move_pawn (pawn : piece) board start_space end_space =
  match pawn with
  | Pawn White ->
      if
        pawn_capture "white" board start_space end_space
        || fst start_space = fst end_space
           && (snd end_space = snd start_space + 1
              || (snd start_space = 2 && snd end_space = 4))
      then true
      else false
  | Pawn Black ->
      if
        pawn_capture "black" board start_space end_space
        || fst start_space = fst end_space
           && (snd end_space = snd start_space - 1
              || (snd start_space = 7 && snd end_space = 5))
      then true
      else false
  | _ -> false

let rec check_verts_rook board position1 position2 =
  if position1 = position2 then true
  else if (find_space position1 board).is_open then
    if snd position1 < snd position2 then
      check_verts_rook board
        (fst position1, snd position1 + 1)
        position2
    else
      check_verts_rook board
        (fst position1, snd position1 - 1)
        position2
  else false

let rec check_horiz_rook board position1 position2 =
  if position1 = position2 then true
  else if (find_space position1 board).is_open then
    if Char.code (fst position1) < Char.code (fst position2) then
      check_horiz_rook board
        (Char.chr (Char.code (fst position1) + 1), snd position1)
        position2
    else
      check_horiz_rook board
        (Char.chr (Char.code (fst position1) - 1), snd position1)
        position2
  else false

let is_valid_move_rook
    piece
    board
    (start_space : position)
    (end_space : position) =
  if
    Char.code (fst start_space) = Char.code (fst end_space)
    && snd start_space <> snd end_space
    || Char.code (fst start_space) <> Char.code (fst end_space)
       && snd start_space = snd end_space
  then
    if fst start_space = fst end_space then
      if snd start_space < snd end_space then
        check_verts_rook board
          (fst start_space, snd start_space + 1)
          end_space
      else
        check_verts_rook board
          (fst start_space, snd start_space - 1)
          end_space
    else if Char.code (fst start_space) < Char.code (fst end_space) then
      check_horiz_rook board
        (Char.chr (Char.code (fst start_space) + 1), snd start_space)
        end_space
    else
      check_horiz_rook board
        (Char.chr (Char.code (fst start_space) + 1), snd start_space)
        end_space
  else false

let is_valid_move_queen piece board start_space end_space =
  is_valid_move_bishop piece board start_space end_space
  || is_valid_move_rook piece board start_space end_space

let is_valid_move board pos_1 pos_2 piece =
  if valid_space pos_1 = false || valid_space pos_2 = false then false
  else
    match piece with
    | Pawn _ -> is_valid_move_pawn piece board pos_1 pos_2
    | Rook _ -> is_valid_move_rook piece board pos_1 pos_2
    | Bishop _ -> is_valid_move_bishop piece board pos_1 pos_2
    | Knight _ -> is_valid_move_knight piece board pos_1 pos_2
    | Queen _ -> is_valid_move_queen piece board pos_1 pos_2
    | King _ -> is_valid_move_king piece board pos_1 pos_2
    | _ -> false

let rec parse_row row =
  match row with
  | [] -> ""
  | h :: t -> print_piece h.piece_id ^ " " ^ parse_row t

let rec parse_board (board : board) (numlst : string list) =
  match numlst with
  | [] -> []
  | n :: m -> (
      match board with
      | [] -> []
      | h :: t -> (n ^ " " ^ parse_row h) :: parse_board t m)

let rec stringify lst =
  let alphalst = "  A B C D E F G H" in
  List.iter print_endline (alphalst :: lst)

let numlist = [ "8"; "7"; "6"; "5"; "4"; "3"; "2"; "1" ]

let print_board board = stringify (parse_board board numlist)

let translate_to_spaces board pos_1 pos_2 =
  let sp1 = find_space pos_1 board in
  let sp2 = find_space pos_2 board in
  (sp1, sp2)

let same_team space1 space2 =
  if space1.color = space2.color then true else false

let rec find_king board (color : string) =
  match board with
  | [] -> raise DoesNotExist
  | h :: t -> (
      let piece = "King " ^ color in
      match
        List.find_opt
          (fun x ->
            x.color = to_color color && x.piece_id = to_piece piece)
          h
      with
      | None -> find_king t color
      | Some sp -> sp)

let rec verify_check (lst : space list) board king_space =
  match lst with
  | [] -> false
  | h :: t ->
      if
        is_valid_move board h.position_id king_space.position_id
          h.piece_id
      then true
      else verify_check t board king_space

let rec in_check
    board
    search_board
    (color : string)
    (king_space : space) =
  let opp =
    if color = "Black" then to_color "White" else to_color "Black"
  in
  match search_board with
  | [] -> false
  | h :: t ->
      let lst = List.filter (fun x -> x.color = opp) h in
      if verify_check lst board king_space then true
      else in_check board t color king_space

let move_away sp1 =
  {
    position_id = sp1.position_id;
    is_open = true;
    piece_id = None;
    color = None;
  }

let move_in sp_moved_to sp_moved_from =
  {
    position_id = sp_moved_to.position_id;
    is_open = false;
    piece_id = sp_moved_from.piece_id;
    color = sp_moved_from.color;
  }

let rec move_space2 (board : board) sp1 sp2 lst1 =
  match lst1 with
  | [] -> []
  | sp_test :: spaces ->
      if sp1 = sp_test then
        move_away sp1 :: move_space2 board sp1 sp2 spaces
      else if sp2 = sp_test then
        move_in sp2 sp1 :: move_space2 board sp1 sp2 spaces
      else sp_test :: move_space2 board sp1 sp2 spaces

let rec move_space (board : board) sp1 sp2 =
  match board with
  | [] -> []
  | lst1 :: t -> move_space2 board sp1 sp2 lst1 :: move_space t sp1 sp2

let move_spaces board pos1 pos2 (colorMove : p_color) =
  let sp1, sp2 = translate_to_spaces board pos1 pos2 in
  if sp1.color != colorMove then
    (([ [ defaultempty ] ], None), "not turn")
  else if same_team sp1 sp2 && sp2.is_open = false then
    (([ [ defaultempty ] ], None), "same team")
  else if is_valid_move board pos1 pos2 sp1.piece_id = false then
    (([ [ defaultempty ] ], None), "invalid move")
  else
    let ck1 =
      in_check board board
        (color_to_str colorMove)
        (find_king board (color_to_str colorMove))
    in
    let mvspace = (move_space board sp1 sp2, sp2.piece_id) in
    if ck1 then
      let ck2 =
        in_check (fst mvspace) (fst mvspace)
          (color_to_str colorMove)
          (find_king (fst mvspace) (color_to_str colorMove))
      in
      if ck2 then (([ [ defaultempty ] ], None), "in check")
      else (mvspace, "clean")
    else (mvspace, "clean")
